"""
阶段3：任务规划器
将复杂需求拆解为工具调用步骤清单
"""

from typing import List, Dict, Any, Optional
import json
import re


class TaskPlanner:
    """任务规划器，负责将复杂任务拆解为步骤"""
    
    def __init__(self):
        self.available_tools = ["get_weather", "calculate", "search_poi", "format_result"]
    
    def parse_task(self, user_input: str, context: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        解析任务，返回步骤清单
        
        参数：
            user_input (str): 用户输入
            context (Dict): 上下文信息
        
        返回：
            List[Dict]: 步骤清单，每个步骤包含 tool, params, description
        """
        steps = []
        
        # 识别任务类型
        if self._is_weather_task(user_input):
            steps.extend(self._plan_weather_task(user_input, context))
        elif self._is_calculation_task(user_input):
            steps.extend(self._plan_calculation_task(user_input))
        elif self._is_search_task(user_input):
            steps.extend(self._plan_search_task(user_input))
        elif self._is_complex_task(user_input):
            steps.extend(self._plan_complex_task(user_input, context))
        else:
            # 默认单步任务
            steps.append({
                "step": 1,
                "tool": None,
                "params": {},
                "description": "无法识别任务类型，需要用户澄清"
            })
        
        return steps
    
    def _is_weather_task(self, user_input: str) -> bool:
        """判断是否为天气相关任务"""
        return bool(re.search(r"天气|温度|气温|下雨|晴天", user_input))
    
    def _is_calculation_task(self, user_input: str) -> bool:
        """判断是否为计算相关任务"""
        return bool(re.search(r"算|计算|加|减|乘|除|等于", user_input))
    
    def _is_search_task(self, user_input: str) -> bool:
        """判断是否为搜索相关任务"""
        return bool(re.search(r"搜索|查找|找|景点|美食|地方", user_input))
    
    def _is_complex_task(self, user_input: str) -> bool:
        """判断是否为复杂任务（需要多工具协作）"""
        # 包含多个关键词，可能是复杂任务
        keywords_count = sum([
            bool(re.search(r"天气", user_input)),
            bool(re.search(r"景点|美食|地方", user_input)),
            bool(re.search(r"算|计算", user_input)),
            bool(re.search(r"规划|推荐|建议", user_input))
        ])
        return keywords_count >= 2
    
    def _plan_weather_task(self, user_input: str, context: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """规划天气任务"""
        steps = []
        
        # 提取城市
        city_match = re.search(r"(北京|上海|广州|深圳|济南|杭州|南京|成都)", user_input)
        city = city_match.group(1) if city_match else (context.get("mentioned_cities", [""])[0] if context else "济南")
        
        steps.append({
            "step": 1,
            "tool": "get_weather",
            "params": {"city": city},
            "description": f"查询{city}的天气信息"
        })
        
        return steps
    
    def _plan_calculation_task(self, user_input: str) -> List[Dict[str, Any]]:
        """规划计算任务"""
        steps = []
        
        # 提取表达式
        expr_match = re.search(r'([0-9+\-*/().\s]+)', user_input)
        if expr_match:
            expression = expr_match.group(1).strip()
            steps.append({
                "step": 1,
                "tool": "calculate",
                "params": {"expression": expression},
                "description": f"计算表达式：{expression}"
            })
        else:
            steps.append({
                "step": 1,
                "tool": "calculate",
                "params": {"expression": ""},
                "description": "需要用户提供计算表达式"
            })
        
        return steps
    
    def _plan_search_task(self, user_input: str) -> List[Dict[str, Any]]:
        """规划搜索任务"""
        steps = []
        
        # 提取关键词
        keyword_match = re.search(r"(搜索|查找|找).*?(趵突泉|大明湖|千佛山|美食|景点|宽厚里|芙蓉街)", user_input)
        if keyword_match:
            keyword = keyword_match.group(2)
            steps.append({
                "step": 1,
                "tool": "search_poi",
                "params": {"keyword": keyword},
                "description": f"搜索关键词：{keyword}"
            })
        else:
            steps.append({
                "step": 1,
                "tool": "search_poi",
                "params": {"keyword": ""},
                "description": "需要用户提供搜索关键词"
            })
        
        return steps
    
    def _plan_complex_task(self, user_input: str, context: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """规划复杂任务（多工具协作）"""
        steps = []
        step_num = 1
        
        # 示例1：生成今日学习周报 -> 读取笔记 + 整理内容 + 保存周报
        if "周报" in user_input or "报告" in user_input:
            # 这里简化处理，实际应该调用多个工具
            steps.append({
                "step": step_num,
                "tool": "search_poi",
                "params": {"keyword": "景点"},
                "description": "读取今日访问的景点信息"
            })
            step_num += 1
            
            steps.append({
                "step": step_num,
                "tool": "get_weather",
                "params": {"city": "济南"},
                "description": "获取今日天气信息"
            })
            step_num += 1
            
            steps.append({
                "step": step_num,
                "tool": "format_result",
                "params": {"format": "report"},
                "description": "整理并格式化周报内容"
            })
        
        # 示例2：查天气 + 推荐景点
        elif "天气" in user_input and ("推荐" in user_input or "景点" in user_input):
            steps.append({
                "step": step_num,
                "tool": "get_weather",
                "params": {"city": "济南"},
                "description": "查询济南天气"
            })
            step_num += 1
            
            steps.append({
                "step": step_num,
                "tool": "search_poi",
                "params": {"keyword": "景点"},
                "description": "搜索推荐景点"
            })
            step_num += 1
            
            steps.append({
                "step": step_num,
                "tool": "format_result",
                "params": {"format": "recommendation"},
                "description": "结合天气信息整理推荐结果"
            })
        
        # 示例3：计算费用 + 查询景点
        elif "算" in user_input and ("景点" in user_input or "地方" in user_input):
            # 提取计算表达式
            expr_match = re.search(r'([0-9+\-*/().\s]+)', user_input)
            if expr_match:
                expression = expr_match.group(1).strip()
                steps.append({
                    "step": step_num,
                    "tool": "calculate",
                    "params": {"expression": expression},
                    "description": f"计算费用：{expression}"
                })
                step_num += 1
            
            # 提取搜索关键词
            keyword_match = re.search(r"(景点|美食|地方|趵突泉|大明湖)", user_input)
            if keyword_match:
                keyword = keyword_match.group(1)
                steps.append({
                    "step": step_num,
                    "tool": "search_poi",
                    "params": {"keyword": keyword},
                    "description": f"搜索相关地点：{keyword}"
                })
                step_num += 1
            
            steps.append({
                "step": step_num,
                "tool": "format_result",
                "params": {"format": "combined"},
                "description": "整合计算结果和搜索结果"
            })
        
        else:
            # 默认复杂任务处理
            steps.append({
                "step": 1,
                "tool": None,
                "params": {},
                "description": "无法识别复杂任务类型，需要用户澄清"
            })
        
        return steps
    
    def format_steps(self, steps: List[Dict[str, Any]]) -> str:
        """格式化步骤清单为可读文本"""
        if not steps:
            return "无步骤"
        
        formatted = []
        for step in steps:
            step_num = step.get("step", 0)
            tool = step.get("tool", "未知")
            desc = step.get("description", "")
            formatted.append(f"步骤{step_num}：{desc}（工具：{tool}）")
        
        return "\n".join(formatted)


# 结果整理工具
def format_result(tool_results: List[Dict[str, Any]], format_type: str = "default") -> str:
    """
    整理多个工具的输出结果
    
    参数：
        tool_results (List[Dict]): 工具执行结果列表
        format_type (str): 整理格式类型
    
    返回：
        str: 整理后的自然语言结果
    """
    if format_type == "report":
        # 周报格式
        result_text = "今日旅游周报\n"
        result_text += "=" * 30 + "\n\n"
        
        for i, result in enumerate(tool_results, 1):
            if "city" in result:  # 天气结果
                city = result.get("city", "")
                current = result.get("current", {})
                result_text += f"天气情况：{city}今日{current.get('condition', '')}，{current.get('temp', '')}℃\n"
            elif "results" in result:  # 搜索结果
                keyword = result.get("keyword", "")
                results = result.get("results", [])
                result_text += f"\n访问地点：\n"
                for poi in results:
                    result_text += f"- {poi.get('name', '')}：{poi.get('description', '')}\n"
        
        return result_text
    
    elif format_type == "recommendation":
        # 推荐格式
        result_text = "根据天气情况，为您推荐：\n\n"
        
        weather_result = None
        poi_result = None
        
        for result in tool_results:
            if "city" in result:
                weather_result = result
            elif "results" in result:
                poi_result = result
        
        if weather_result:
            city = weather_result.get("city", "")
            current = weather_result.get("current", {})
            condition = current.get("condition", "")
            temp = current.get("temp", "")
            result_text += f"今日{city}天气：{condition}，{temp}℃。"
            
            if "晴" in condition or "多云" in condition:
                result_text += "天气不错，适合户外活动！\n\n"
            elif "雨" in condition:
                result_text += "有雨，建议选择室内景点。\n\n"
        
        if poi_result:
            results = poi_result.get("results", [])
            result_text += "推荐地点：\n"
            for i, poi in enumerate(results[:3], 1):
                result_text += f"{i}. {poi.get('name', '')} - {poi.get('address', '')}\n"
                result_text += f"   {poi.get('description', '')}\n"
        
        return result_text
    
    elif format_type == "combined":
        # 组合格式
        result_text = ""
        
        for result in tool_results:
            if "result" in result and isinstance(result["result"], (int, float)):  # 计算结果
                expr = result.get("expression", "")
                calc_result = result["result"]
                result_text += f"计算结果：{expr} = {calc_result}\n\n"
            elif "results" in result:  # 搜索结果
                keyword = result.get("keyword", "")
                results = result.get("results", [])
                result_text += f"搜索'{keyword}'找到以下地点：\n"
                for poi in results:
                    result_text += f"- {poi.get('name', '')}：{poi.get('address', '')}\n"
        
        return result_text
    
    else:
        # 默认格式：简单拼接
        result_text = ""
        for i, result in enumerate(tool_results, 1):
            result_text += f"结果{i}：{json.dumps(result, ensure_ascii=False)}\n"
        return result_text

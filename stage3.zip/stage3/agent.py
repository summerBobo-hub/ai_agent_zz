"""
阶段3：支持任务规划与多工具协作的Agent
"""

import json
import re
import os
import httpx
from typing import Dict, Any, Optional, List
from dotenv import load_dotenv
import sys
# 添加父目录到路径，以便导入stage1和stage2的模块
parent_dir = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, parent_dir)
from stage1.tools import call_tool, TOOLS
from stage2.memory import memory
from planner import TaskPlanner, format_result

# 加载环境变量
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '.env'))


class PlanningAgent:
    """支持任务规划的Agent"""
    
    def __init__(self):
        self.ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
        self.model_name = os.getenv("LLM_QWEN2_MODEL_PATH", "qwen2:latest")
        self.generate_url = f"{self.ollama_base_url}/api/generate"
        self.planner = TaskPlanner()
    
    async def _call_llm(self, prompt: str) -> Optional[str]:
        """调用LLM生成回复"""
        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 1000
            }
        }
        
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(self.generate_url, json=payload)
                if response.status_code == 200:
                    result = response.json()
                    return result.get("response", "")
                else:
                    print(f"LLM调用失败: {response.status_code} - {response.text}")
                    return None
        except Exception as e:
            print(f"LLM调用异常: {e}")
            return None
    
    async def process(self, user_input: str, session_id: str = "default") -> str:
        """
        处理用户输入，支持任务规划和多工具协作
        
        参数：
            user_input (str): 用户输入
            session_id (str): 会话ID
        """
        # 添加用户输入到记忆
        memory.add_turn(session_id, "user", user_input)
        
        # 获取上下文
        context = memory.extract_context(session_id)
        history = memory.get_formatted_history(session_id, max_turns=3)
        
        # 任务规划：拆解复杂任务为步骤
        steps = self.planner.parse_task(user_input, context)
        
        if not steps or steps[0].get("tool") is None:
            response = "我理解您说的是：" + user_input + "。但我目前只能帮您查天气、算数学题、搜索景点。请告诉我您需要什么帮助？"
            memory.add_turn(session_id, "assistant", response)
            return response
        
        # 执行步骤
        tool_results = []
        executed_steps = []
        
        for step in steps:
            tool_name = step.get("tool")
            params = step.get("params", {})
            description = step.get("description", "")
            
            if tool_name == "format_result":
                # 结果整理步骤
                format_type = params.get("format", "default")
                formatted = format_result(tool_results, format_type)
                executed_steps.append({
                    "step": step.get("step"),
                    "description": description,
                    "result": formatted
                })
                continue
            
            if tool_name not in TOOLS:
                continue
            
            # 调用工具
            try:
                result = call_tool(tool_name, **params)
                tool_results.append(result)
                executed_steps.append({
                    "step": step.get("step"),
                    "description": description,
                    "tool": tool_name,
                    "result": result
                })
            except Exception as e:
                executed_steps.append({
                    "step": step.get("step"),
                    "description": description,
                    "error": str(e)
                })
        
        # 如果有format_result步骤，使用其输出
        final_result = None
        for step_info in executed_steps:
            if "result" in step_info and isinstance(step_info["result"], str) and len(step_info["result"]) > 50:
                final_result = step_info["result"]
                break
        
        # 如果没有格式化结果，使用LLM整理
        if not final_result:
            final_result = await self._format_results_with_llm(user_input, tool_results, executed_steps)
        
        memory.add_turn(session_id, "assistant", final_result)
        return final_result
    
    async def _format_results_with_llm(self, user_input: str, tool_results: List[Dict], executed_steps: List[Dict]) -> str:
        """使用LLM整理多个工具的输出结果"""
        # 构建结果摘要
        results_summary = []
        for i, result in enumerate(tool_results, 1):
            if "city" in result:  # 天气结果
                city = result.get("city", "")
                current = result.get("current", {})
                results_summary.append(f"结果{i}（天气）：{city}今日{current.get('condition', '')}，{current.get('temp', '')}℃")
            elif "result" in result:  # 计算结果
                expr = result.get("expression", "")
                calc_result = result.get("result")
                results_summary.append(f"结果{i}（计算）：{expr} = {calc_result}")
            elif "results" in result:  # 搜索结果
                keyword = result.get("keyword", "")
                pois = result.get("results", [])
                poi_names = [poi.get("name", "") for poi in pois[:3]]
                results_summary.append(f"结果{i}（搜索）：找到{len(pois)}个地点，包括{', '.join(poi_names)}")
        
        prompt = f"""用户请求：{user_input}

工具执行结果：
{chr(10).join(results_summary)}

请将这些结果整理成一段连贯的自然语言回复，要求：
1. 语言自然流畅，不要分条列举
2. 结合用户原始请求，提供有意义的回复
3. 如果结果之间有逻辑关系，要体现出来
4. 用中文回复，简洁明了

回复："""
        
        llm_output = await self._call_llm(prompt)
        if llm_output:
            return llm_output.strip()
        
        # LLM失败时的备用格式化
        return self._fallback_format(tool_results)
    
    def _fallback_format(self, tool_results: List[Dict]) -> str:
        """备用格式化方法"""
        if len(tool_results) == 1:
            result = tool_results[0]
            if "city" in result:
                city = result.get("city", "")
                current = result.get("current", {})
                return f"{city}今日天气：{current.get('condition', '')}，{current.get('temp', '')}℃"
            elif "result" in result:
                expr = result.get("expression", "")
                calc_result = result.get("result")
                return f"{expr} = {calc_result}"
            elif "results" in result:
                keyword = result.get("keyword", "")
                results = result.get("results", [])
                result_text = f"找到以下与'{keyword}'相关的地点：\n"
                for poi in results:
                    result_text += f"- {poi.get('name', '')}：{poi.get('address', '')}\n"
                return result_text
        
        # 多个结果
        result_text = "已完成以下操作：\n"
        for i, result in enumerate(tool_results, 1):
            if "city" in result:
                city = result.get("city", "")
                current = result.get("current", {})
                result_text += f"{i}. 查询了{city}的天气：{current.get('condition', '')}，{current.get('temp', '')}℃\n"
            elif "result" in result:
                expr = result.get("expression", "")
                calc_result = result.get("result")
                result_text += f"{i}. 计算结果：{expr} = {calc_result}\n"
            elif "results" in result:
                keyword = result.get("keyword", "")
                results = result.get("results", [])
                result_text += f"{i}. 搜索'{keyword}'找到{len(results)}个地点\n"
        
        return result_text


async def main():
    """测试主函数"""
    agent = PlanningAgent()
    session_id = "test_session"
    
    # 测试用例
    test_cases = [
        "查济南天气并推荐景点",  # 多工具协作
        "算一下100加200，然后搜索美食",  # 计算+搜索
        "生成今日旅游周报"  # 复杂任务
    ]
    
    print("=" * 50)
    print("阶段3测试：任务规划与多工具协作")
    print("=" * 50)
    
    for user_input in test_cases:
        print(f"\n用户输入：{user_input}")
        print("-" * 50)
        response = await agent.process(user_input, session_id)
        print(f"Agent回复：\n{response}")
        print("=" * 50)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

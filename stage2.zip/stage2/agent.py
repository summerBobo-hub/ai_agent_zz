"""
阶段2：增强版Agent
添加上下文记忆、错误处理、Prompt优化
"""

import json
import re
import os
import httpx
from typing import Dict, Any, Optional
from dotenv import load_dotenv
import sys
# 添加父目录到路径，以便导入stage1的工具
parent_dir = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, parent_dir)
from stage1.tools import call_tool, TOOLS
from memory import memory

# 加载环境变量
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '.env'))


class EnhancedAgent:
    """增强版Agent，支持记忆、错误处理、Prompt优化"""
    
    def __init__(self):
        self.ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
        self.model_name = os.getenv("LLM_QWEN2_MODEL_PATH", "qwen2:latest")
        self.generate_url = f"{self.ollama_base_url}/api/generate"
    
    def _build_tool_prompt(self) -> str:
        """构建工具说明的Prompt"""
        tool_descriptions = []
        for tool_name, tool_info in TOOLS.items():
            params_desc = []
            for param_name, param_info in tool_info["parameters"].items():
                required = "必需" if param_info.get("required", False) else "可选"
                params_desc.append(f"  - {param_name} ({param_info['type']}): {param_info['description']} [{required}]")
            
            tool_descriptions.append(
                f"工具名: {tool_name}\n"
                f"功能: {tool_info['description']}\n"
                f"参数:\n" + "\n".join(params_desc)
            )
        
        return "\n\n".join(tool_descriptions)
    
    async def _call_llm(self, prompt: str) -> Optional[str]:
        """调用LLM生成回复"""
        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 800
            }
        }
        
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(self.generate_url, json=payload)
                if response.status_code == 200:
                    result = response.json()
                    return result.get("response", "")
                else:
                    print(f"LLM调用失败: {response.status_code} - {response.text}")
                    return None
        except httpx.TimeoutException:
            print("LLM调用超时")
            return None
        except Exception as e:
            print(f"LLM调用异常: {e}")
            return None
    
    def _parse_llm_response(self, llm_output: str) -> Dict[str, Any]:
        """解析LLM输出，提取工具名和参数"""
        # 尝试解析JSON格式
        json_match = re.search(r'\{[^{}]*"tool"[^{}]*\}', llm_output, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                return parsed
            except:
                pass
        
        # 尝试提取工具名
        tool_patterns = {
            "get_weather": r"(查|查询|看).*?天气|天气.*?(查|查询|看)",
            "calculate": r"(算|计算|求).*?[0-9+\-*/]|[0-9+\-*/].*?(算|计算|求)",
            "search_poi": r"(查|搜索|找).*?(景点|美食|POI|地方|去哪)"
        }
        
        for tool_name, pattern in tool_patterns.items():
            if re.search(pattern, llm_output, re.IGNORECASE):
                params = {}
                
                if tool_name == "get_weather":
                    city_match = re.search(r"(北京|上海|广州|深圳|济南|杭州|南京|成都)", llm_output)
                    if city_match:
                        params["city"] = city_match.group(1)
                
                elif tool_name == "calculate":
                    expr_match = re.search(r'([0-9+\-*/().\s]+)', llm_output)
                    if expr_match:
                        params["expression"] = expr_match.group(1).strip()
                
                elif tool_name == "search_poi":
                    keyword_match = re.search(r"(趵突泉|大明湖|千佛山|美食|景点|宽厚里|芙蓉街)", llm_output)
                    if keyword_match:
                        params["keyword"] = keyword_match.group(1)
                
                return {"tool": tool_name, "params": params}
        
        return {"tool": None, "params": {}}
    
    def _validate_tool_params(self, tool_name: str, params: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """
        验证工具参数
        
        返回：
            (is_valid, error_message)
        """
        if tool_name not in TOOLS:
            return False, f"未知工具: {tool_name}"
        
        tool_info = TOOLS[tool_name]
        required_params = [
            name for name, info in tool_info["parameters"].items()
            if info.get("required", False)
        ]
        
        # 检查必需参数
        for param_name in required_params:
            if param_name not in params or not params[param_name]:
                return False, f"缺少必需参数: {param_name}"
        
        # 特定工具的参数验证
        if tool_name == "get_weather":
            city = params.get("city", "")
            if city and not isinstance(city, str):
                return False, "城市参数必须是字符串"
        
        elif tool_name == "calculate":
            expression = params.get("expression", "")
            if not expression:
                return False, "请提供要计算的数学表达式"
            # 检查表达式安全性
            if not re.match(r'^[\d+\-*/().\s]+$', expression):
                return False, "表达式包含非法字符，只支持数字和基本运算符"
        
        elif tool_name == "search_poi":
            keyword = params.get("keyword", "")
            if not keyword:
                return False, "请提供搜索关键词"
        
        return True, None
    
    def _handle_tool_error(self, tool_name: str, error: str) -> str:
        """处理工具执行错误，返回友好的错误提示"""
        error_messages = {
            "get_weather": {
                "missing_city": "请告诉我您要查询哪个城市的天气？例如：查北京天气",
                "invalid_city": "请输入正确的城市名称",
                "api_error": "天气服务暂时不可用，请稍后重试"
            },
            "calculate": {
                "missing_expression": "请告诉我您要计算什么？例如：算一下100加200",
                "invalid_expression": "请输入正确的数学表达式，只支持数字和基本运算符（+、-、*、/）",
                "calculation_error": "计算失败，请检查表达式是否正确"
            },
            "search_poi": {
                "missing_keyword": "请告诉我您要搜索什么？例如：搜索趵突泉",
                "no_results": "未找到相关结果，请尝试其他关键词"
            }
        }
        
        tool_errors = error_messages.get(tool_name, {})
        for key, msg in tool_errors.items():
            if key in error.lower():
                return msg
        
        return f"执行{tool_name}时出错：{error}"
    
    async def process(self, user_input: str, session_id: str = "default") -> str:
        """
        处理用户输入，支持多轮对话和错误处理
        
        参数：
            user_input (str): 用户输入
            session_id (str): 会话ID，用于记忆管理
        """
        # 添加上一轮用户输入到记忆
        memory.add_turn(session_id, "user", user_input)
        
        # 获取对话历史
        history = memory.get_formatted_history(session_id, max_turns=5)
        context = memory.extract_context(session_id)
        
        # 构建增强的Prompt
        tool_prompt = self._build_tool_prompt()
        
        # 优化后的Prompt，支持主动追问和模糊指令解析
        prompt = f"""你是一个智能助手，能够理解用户意图并调用相应工具。

可用工具：
{tool_prompt}

对话历史：
{history if history else "（这是第一轮对话）"}

上下文信息：
- 之前提到的城市：{', '.join(context['mentioned_cities']) if context['mentioned_cities'] else '无'}
- 之前提到的关键词：{', '.join(context['mentioned_keywords']) if context['mentioned_keywords'] else '无'}

用户当前输入：{user_input}

重要提示：
1. 如果用户输入模糊或不完整（如只说"查天气"、"算一下"），请主动追问缺失的参数
2. 如果用户使用代词（如"那里"、"它"），请结合对话历史推断指代内容
3. 如果用户说"明天呢"、"那个地方"等，请结合上下文理解

请分析用户意图，并返回JSON格式：
{{
    "tool": "工具名（如果无法确定，返回null）",
    "params": {{"参数名": "参数值"}},
    "need_clarification": true/false,
    "clarification_question": "如果需要追问，这里写问题"
}}

如果用户输入不明确，设置 need_clarification=true 并给出追问问题。
"""
        
        # 调用LLM解析意图
        try:
            llm_output = await self._call_llm(prompt)
            if not llm_output:
                memory.add_turn(session_id, "assistant", "抱歉，LLM服务暂时不可用，请稍后重试。")
                return "抱歉，LLM服务暂时不可用，请稍后重试。"
        except Exception as e:
            error_msg = f"LLM调用异常：{str(e)}"
            memory.add_turn(session_id, "assistant", error_msg)
            return error_msg
        
        # 解析LLM输出
        try:
            parsed = self._parse_llm_response(llm_output)
            tool_name = parsed.get("tool")
            params = parsed.get("params", {})
            need_clarification = parsed.get("need_clarification", False)
            clarification_question = parsed.get("clarification_question", "")
            
            # 如果需要追问
            if need_clarification and clarification_question:
                memory.add_turn(session_id, "assistant", clarification_question)
                return clarification_question
            
            # 如果没有识别到工具
            if not tool_name:
                # 尝试从上下文推断
                if context["last_intent"]:
                    if context["last_intent"] == "weather" and "天气" in user_input:
                        # 用户可能是在追问天气
                        last_city = context["mentioned_cities"][-1] if context["mentioned_cities"] else "济南"
                        tool_name = "get_weather"
                        params = {"city": last_city}
                    elif context["last_intent"] == "calculate" and ("算" in user_input or "计算" in user_input):
                        return "请告诉我您要计算什么？例如：100 + 200"
                    elif context["last_intent"] == "search_poi" and ("景点" in user_input or "美食" in user_input):
                        return "请告诉我您要搜索什么？例如：搜索趵突泉"
                
                if not tool_name:
                    response = f"我理解您说的是：{user_input}。但我目前只能帮您查天气、算数学题、搜索景点。请告诉我您需要什么帮助？"
                    memory.add_turn(session_id, "assistant", response)
                    return response
            
            # 验证参数
            is_valid, error_msg = self._validate_tool_params(tool_name, params)
            if not is_valid:
                friendly_error = self._handle_tool_error(tool_name, error_msg)
                memory.add_turn(session_id, "assistant", friendly_error)
                return friendly_error
            
            # 调用工具（带错误处理）
            try:
                tool_result = call_tool(tool_name, **params)
                
                if "error" in tool_result:
                    friendly_error = self._handle_tool_error(tool_name, tool_result["error"])
                    memory.add_turn(session_id, "assistant", friendly_error)
                    return friendly_error
                
                # 格式化结果
                response = self._format_tool_result(tool_name, tool_result)
                memory.add_turn(session_id, "assistant", response)
                return response
                
            except Exception as e:
                error_msg = f"工具执行异常：{str(e)}"
                friendly_error = self._handle_tool_error(tool_name, error_msg)
                memory.add_turn(session_id, "assistant", friendly_error)
                return friendly_error
                
        except Exception as e:
            error_msg = f"处理请求时出错：{str(e)}"
            memory.add_turn(session_id, "assistant", error_msg)
            return error_msg
    
    def _format_tool_result(self, tool_name: str, tool_result: Dict[str, Any]) -> str:
        """格式化工具执行结果"""
        if tool_name == "get_weather":
            city = tool_result.get("city", "未知")
            current = tool_result.get("current", {})
            forecast = tool_result.get("forecast", [])
            
            response = f"{city}今日天气：{current.get('condition', '未知')}，{current.get('temp', '未知')}℃，湿度{current.get('humidity', '未知')}%"
            
            if forecast:
                response += "\n未来几天预报："
                for day in forecast[:3]:
                    response += f"\n{day.get('date', '')}：{day.get('condition', '')}，{day.get('low', '')}~{day.get('high', '')}℃"
            
            return response
        
        elif tool_name == "calculate":
            expr = tool_result.get("expression", "")
            result = tool_result.get("result")
            if result is not None:
                return f"{expr} = {result}"
            else:
                return f"计算失败：{tool_result.get('error', '未知错误')}"
        
        elif tool_name == "search_poi":
            keyword = tool_result.get("keyword", "")
            results = tool_result.get("results", [])
            if results:
                result_text = f"找到以下与'{keyword}'相关的地点：\n"
                for i, poi in enumerate(results, 1):
                    result_text += f"{i}. {poi.get('name', '未知')} - {poi.get('address', '未知地址')}\n"
                    desc = poi.get('description', '')
                    if desc:
                        result_text += f"   {desc}\n"
                return result_text
            else:
                return f"未找到与'{keyword}'相关的地点。"
        
        return json.dumps(tool_result, ensure_ascii=False, indent=2)


async def main():
    """测试主函数"""
    agent = EnhancedAgent()
    session_id = "test_session"
    
    # 测试用例
    test_cases = [
        "查天气",  # 模糊输入，应该追问城市
        "查北京天气",  # 正常输入
        "明天呢",  # 上下文相关
        "算一下",  # 模糊输入，应该追问表达式
        "100 + 200",  # 正常输入
        "搜索",  # 模糊输入，应该追问关键词
        "搜索趵突泉"  # 正常输入
    ]
    
    print("=" * 50)
    print("阶段2测试：上下文记忆与错误处理")
    print("=" * 50)
    
    for user_input in test_cases:
        print(f"\n用户输入：{user_input}")
        print("-" * 50)
        response = await agent.process(user_input, session_id)
        print(f"Agent回复：{response}")
        print("=" * 50)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

"""
阶段2：上下文记忆管理
实现对话历史存储和管理，支持多轮交互
"""

from typing import List, Dict, Optional
from datetime import datetime
import json


class ConversationMemory:
    """对话记忆管理器"""
    
    def __init__(self):
        # 使用字典存储不同会话的历史记录
        # key: session_id, value: List[Dict] 对话历史
        self.memories: Dict[str, List[Dict[str, str]]] = {}
    
    def add_turn(self, session_id: str, role: str, content: str):
        """
        添加一轮对话
        
        参数：
            session_id (str): 会话ID
            role (str): 角色，"user" 或 "assistant"
            content (str): 对话内容
        """
        if session_id not in self.memories:
            self.memories[session_id] = []
        
        self.memories[session_id].append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
    
    def get_history(self, session_id: str, max_turns: int = 10) -> List[Dict[str, str]]:
        """
        获取对话历史
        
        参数：
            session_id (str): 会话ID
            max_turns (int): 最大返回轮数，默认10轮
        
        返回：
            List[Dict]: 对话历史列表
        """
        if session_id not in self.memories:
            return []
        
        history = self.memories[session_id]
        # 返回最近的max_turns轮对话
        return history[-max_turns:] if len(history) > max_turns else history
    
    def get_formatted_history(self, session_id: str, max_turns: int = 10) -> str:
        """
        获取格式化的对话历史（用于Prompt）
        
        参数：
            session_id (str): 会话ID
            max_turns (int): 最大返回轮数
        
        返回：
            str: 格式化的对话历史文本
        """
        history = self.get_history(session_id, max_turns)
        if not history:
            return ""
        
        formatted = []
        for turn in history:
            role = "用户" if turn["role"] == "user" else "助手"
            formatted.append(f"{role}：{turn['content']}")
        
        return "\n".join(formatted)
    
    def clear_history(self, session_id: str):
        """清空指定会话的历史记录"""
        if session_id in self.memories:
            del self.memories[session_id]
    
    def extract_context(self, session_id: str) -> Dict[str, any]:
        """
        从历史对话中提取上下文信息
        
        返回：
            Dict: 包含提取的上下文信息
        """
        history = self.get_history(session_id, max_turns=5)
        
        context = {
            "mentioned_cities": [],
            "mentioned_keywords": [],
            "last_intent": None
        }
        
        # 提取提到的城市
        import re
        cities = ["北京", "上海", "广州", "深圳", "济南", "杭州", "南京", "成都"]
        for turn in history:
            for city in cities:
                if city in turn["content"]:
                    if city not in context["mentioned_cities"]:
                        context["mentioned_cities"].append(city)
        
        # 提取关键词
        keywords = ["天气", "景点", "美食", "计算", "算"]
        for turn in history:
            for keyword in keywords:
                if keyword in turn["content"]:
                    if keyword not in context["mentioned_keywords"]:
                        context["mentioned_keywords"].append(keyword)
        
        # 提取最后意图（简单规则）
        if history:
            last_user_msg = None
            for turn in reversed(history):
                if turn["role"] == "user":
                    last_user_msg = turn["content"]
                    break
            
            if last_user_msg:
                if "天气" in last_user_msg:
                    context["last_intent"] = "weather"
                elif "算" in last_user_msg or "计算" in last_user_msg:
                    context["last_intent"] = "calculate"
                elif "景点" in last_user_msg or "美食" in last_user_msg:
                    context["last_intent"] = "search_poi"
        
        return context


# 全局记忆实例
memory = ConversationMemory()

"""
阶段1：LLM 与工具联动
实现 LLM 解析意图 → 自动选择对应工具 → 执行工具并返回结果
"""

import json
import re
import os
import httpx
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from tools import call_tool, TOOLS

# 加载环境变量
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '.env'))


class SimpleAgent:
    """简单的Agent，实现LLM与工具联动"""
    
    def __init__(self):
        self.ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
        self.model_name = os.getenv("LLM_QWEN2_MODEL_PATH", "qwen2:latest")
        self.generate_url = f"{self.ollama_base_url}/api/generate"
    
    def _build_tool_prompt(self) -> str:
        """构建工具说明的Prompt"""
        tool_descriptions = []
        for tool_name, tool_info in TOOLS.items():
            params_desc = []
            for param_name, param_info in tool_info["parameters"].items():
                required = "必需" if param_info.get("required", False) else "可选"
                params_desc.append(f"  - {param_name} ({param_info['type']}): {param_info['description']} [{required}]")
            
            tool_descriptions.append(
                f"工具名: {tool_name}\n"
                f"功能: {tool_info['description']}\n"
                f"参数:\n" + "\n".join(params_desc)
            )
        
        return "\n\n".join(tool_descriptions)
    
    async def _call_llm(self, prompt: str) -> Optional[str]:
        """调用LLM生成回复"""
        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 500
            }
        }
        
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(self.generate_url, json=payload)
                if response.status_code == 200:
                    result = response.json()
                    return result.get("response", "")
                else:
                    print(f"LLM调用失败: {response.status_code} - {response.text}")
                    return None
        except Exception as e:
            print(f"LLM调用异常: {e}")
            return None
    
    def _parse_llm_response(self, llm_output: str) -> Dict[str, Any]:
        """解析LLM输出，提取工具名和参数"""
        # 尝试解析JSON格式
        json_match = re.search(r'\{[^{}]*"tool"[^{}]*\}', llm_output, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                return parsed
            except:
                pass
        
        # 尝试提取工具名
        tool_patterns = {
            "get_weather": r"(查|查询|看).*?天气|天气.*?(查|查询|看)",
            "calculate": r"(算|计算|求).*?[0-9+\-*/]|[0-9+\-*/].*?(算|计算|求)",
            "search_poi": r"(查|搜索|找).*?(景点|美食|POI|地方|去哪)"
        }
        
        for tool_name, pattern in tool_patterns.items():
            if re.search(pattern, llm_output, re.IGNORECASE):
                # 提取参数
                params = {}
                
                if tool_name == "get_weather":
                    city_match = re.search(r"(北京|上海|广州|深圳|济南|杭州|南京|成都)", llm_output)
                    if city_match:
                        params["city"] = city_match.group(1)
                
                elif tool_name == "calculate":
                    expr_match = re.search(r'([0-9+\-*/().\s]+)', llm_output)
                    if expr_match:
                        params["expression"] = expr_match.group(1).strip()
                
                elif tool_name == "search_poi":
                    keyword_match = re.search(r"(趵突泉|大明湖|千佛山|美食|景点|宽厚里|芙蓉街)", llm_output)
                    if keyword_match:
                        params["keyword"] = keyword_match.group(1)
                
                return {"tool": tool_name, "params": params}
        
        return {"tool": None, "params": {}}
    
    async def process(self, user_input: str) -> str:
        """
        处理用户输入，返回回复
        
        流程：
        1. LLM解析用户意图，识别需要调用的工具和参数
        2. 调用对应工具
        3. 整理结果并返回
        """
        # 构建Prompt
        tool_prompt = self._build_tool_prompt()
        
        prompt = f"""你是一个智能助手，能够理解用户意图并调用相应工具。

可用工具：
{tool_prompt}

用户输入：{user_input}

请分析用户意图，并返回JSON格式：
{{
    "tool": "工具名",
    "params": {{"参数名": "参数值"}}
}}

如果无法识别意图，返回：
{{
    "tool": null,
    "params": {{}}
}}
"""
        
        # 调用LLM解析意图
        llm_output = await self._call_llm(prompt)
        if not llm_output:
            return "抱歉，LLM服务暂时不可用，请稍后重试。"
        
        # 解析LLM输出
        parsed = self._parse_llm_response(llm_output)
        tool_name = parsed.get("tool")
        params = parsed.get("params", {})
        
        if not tool_name:
            return f"我理解您说的是：{user_input}。但我目前只能帮您查天气、算数学题、搜索景点。请告诉我您需要什么帮助？"
        
        # 调用工具
        tool_result = call_tool(tool_name, **params)
        
        # 格式化结果
        if "error" in tool_result:
            return f"执行工具时出错：{tool_result['error']}"
        
        # 根据工具类型格式化输出
        if tool_name == "get_weather":
            city = tool_result.get("city", "未知")
            current = tool_result.get("current", {})
            return f"{city}今日天气：{current.get('condition', '未知')}，{current.get('temp', '未知')}℃，湿度{current.get('humidity', '未知')}%"
        
        elif tool_name == "calculate":
            expr = tool_result.get("expression", "")
            result = tool_result.get("result")
            if result is not None:
                return f"{expr} = {result}"
            else:
                return f"计算失败：{tool_result.get('error', '未知错误')}"
        
        elif tool_name == "search_poi":
            keyword = tool_result.get("keyword", "")
            results = tool_result.get("results", [])
            if results:
                result_text = f"找到以下与'{keyword}'相关的地点：\n"
                for i, poi in enumerate(results, 1):
                    result_text += f"{i}. {poi.get('name', '未知')} - {poi.get('address', '未知地址')}\n"
                    result_text += f"   {poi.get('description', '')}\n"
                return result_text
            else:
                return f"未找到与'{keyword}'相关的地点。"
        
        return json.dumps(tool_result, ensure_ascii=False, indent=2)


async def main():
    """测试主函数"""
    agent = SimpleAgent()
    
    # 测试用例
    test_cases = [
        "查北京天气",
        "100 + 200等于多少",
        "搜索趵突泉",
        "帮我算一下50乘以0.8"
    ]
    
    print("=" * 50)
    print("阶段1测试：LLM与工具联动")
    print("=" * 50)
    
    for user_input in test_cases:
        print(f"\n用户输入：{user_input}")
        print("-" * 50)
        response = await agent.process(user_input)
        print(f"Agent回复：{response}")
        print("=" * 50)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

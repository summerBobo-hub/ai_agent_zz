"""
阶段1：核心工具函数
包含3个核心工具：查天气、算题、查景点
"""

import json
import re
from typing import Dict, Any, Optional


def get_weather(city: str = "济南") -> Dict[str, Any]:
    """
    查天气工具
    
    功能：查询指定城市的天气信息
    
    参数：
        city (str): 城市名称，默认"济南"
    
    返回：
        Dict: 包含城市、当前天气、预报信息的字典
    """
    # 模拟天气数据（实际项目中可调用真实API）
    # 这里使用简化的模拟数据，实际应调用天气API
    weather_data = {
        "济南": {
            "current": {
                "temp": 22,
                "condition": "晴",
                "humidity": 60,
                "wind": "东南风 3级"
            },
            "forecast": [
                {"date": "2026-03-16", "high": 25, "low": 15, "condition": "晴"},
                {"date": "2026-03-17", "high": 23, "low": 14, "condition": "多云"},
                {"date": "2026-03-18", "high": 20, "low": 12, "condition": "小雨"}
            ]
        },
        "北京": {
            "current": {
                "temp": 18,
                "condition": "多云",
                "humidity": 55,
                "wind": "北风 2级"
            },
            "forecast": [
                {"date": "2026-03-16", "high": 20, "low": 10, "condition": "多云"},
                {"date": "2026-03-17", "high": 22, "low": 12, "condition": "晴"}
            ]
        }
    }
    
    # 如果城市不在数据中，返回默认数据
    city_data = weather_data.get(city, weather_data["济南"])
    
    return {
        "city": city,
        "current": city_data["current"],
        "forecast": city_data["forecast"],
        "source": "模拟数据"
    }


def calculate(expression: str) -> Dict[str, Any]:
    """
    算题工具
    
    功能：安全地执行数学表达式计算
    
    参数：
        expression (str): 数学表达式，如 "100 + 200"、"50 * 0.8"
    
    返回：
        Dict: 包含表达式和计算结果的字典
    """
    # 移除空格
    expression = expression.strip()
    
    # 安全检查：只允许数字、运算符、小数点、括号
    if not re.match(r'^[\d+\-*/().\s]+$', expression):
        return {
            "expression": expression,
            "result": None,
            "error": "表达式包含非法字符，只支持数字和基本运算符"
        }
    
    try:
        # 使用 eval 计算（在实际生产环境中应使用更安全的方法）
        result = eval(expression)
        return {
            "expression": expression,
            "result": result
        }
    except Exception as e:
        return {
            "expression": expression,
            "result": None,
            "error": f"计算错误: {str(e)}"
        }


def search_poi(keyword: str, category: Optional[str] = None) -> Dict[str, Any]:
    """
    查景点工具
    
    功能：搜索济南的景点、美食等POI信息
    
    参数：
        keyword (str): 搜索关键词，如 "趵突泉"、"美食"
        category (str, optional): 类别筛选，如 "景点"、"美食"
    
    返回：
        Dict: 包含关键词和搜索结果列表的字典
    """
    # 模拟POI数据（实际项目中应从数据库或API获取）
    poi_database = {
        "趵突泉": [
            {
                "name": "趵突泉公园",
                "address": "济南市历下区趵突泉南路1号",
                "category": "景点",
                "description": "济南三大名胜之一，有天下第一泉的美誉"
            }
        ],
        "美食": [
            {
                "name": "宽厚里",
                "address": "济南市历下区宽厚里商业街",
                "category": "美食",
                "description": "济南著名美食街，汇集各种特色小吃"
            },
            {
                "name": "芙蓉街",
                "address": "济南市历下区芙蓉街",
                "category": "美食",
                "description": "历史悠久的传统美食街"
            }
        ],
        "大明湖": [
            {
                "name": "大明湖公园",
                "address": "济南市历下区大明湖路271号",
                "category": "景点",
                "description": "济南三大名胜之一，湖光山色美不胜收"
            }
        ],
        "千佛山": [
            {
                "name": "千佛山风景区",
                "address": "济南市历下区经十路18号",
                "category": "景点",
                "description": "济南三大名胜之一，登高望远的好去处"
            }
        ]
    }
    
    # 搜索逻辑
    results = []
    
    # 精确匹配
    if keyword in poi_database:
        results.extend(poi_database[keyword])
    
    # 模糊匹配
    for key, pois in poi_database.items():
        if keyword in key or key in keyword:
            results.extend(pois)
    
    # 类别筛选
    if category:
        results = [poi for poi in results if poi.get("category") == category]
    
    # 去重（基于名称）
    seen = set()
    unique_results = []
    for poi in results:
        if poi["name"] not in seen:
            seen.add(poi["name"])
            unique_results.append(poi)
    
    # 如果没有结果，返回默认推荐
    if not unique_results:
        unique_results = [
            {
                "name": "济南市",
                "address": "山东省济南市",
                "category": "城市",
                "description": "泉城济南，欢迎您！"
            }
        ]
    
    return {
        "keyword": keyword,
        "category": category,
        "results": unique_results[:5]  # 最多返回5个结果
    }


# 工具注册表
TOOLS = {
    "get_weather": {
        "function": get_weather,
        "description": "查询指定城市的天气信息",
        "parameters": {
            "city": {"type": "string", "description": "城市名称，默认'济南'", "required": False}
        }
    },
    "calculate": {
        "function": calculate,
        "description": "执行数学表达式计算",
        "parameters": {
            "expression": {"type": "string", "description": "数学表达式，如 '100 + 200'", "required": True}
        }
    },
    "search_poi": {
        "function": search_poi,
        "description": "搜索济南的景点、美食等POI信息",
        "parameters": {
            "keyword": {"type": "string", "description": "搜索关键词", "required": True},
            "category": {"type": "string", "description": "类别筛选，如'景点'、'美食'", "required": False}
        }
    }
}


def call_tool(tool_name: str, **kwargs) -> Dict[str, Any]:
    """
    调用指定工具
    
    参数：
        tool_name (str): 工具名称
        **kwargs: 工具参数
    
    返回：
        Dict: 工具执行结果
    """
    if tool_name not in TOOLS:
        return {
            "error": f"未知工具: {tool_name}",
            "available_tools": list(TOOLS.keys())
        }
    
    tool = TOOLS[tool_name]
    try:
        result = tool["function"](**kwargs)
        return result
    except Exception as e:
        return {
            "error": f"工具执行失败: {str(e)}",
            "tool": tool_name
        }
